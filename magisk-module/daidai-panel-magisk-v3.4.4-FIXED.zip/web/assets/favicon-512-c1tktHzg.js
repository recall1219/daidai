const o="/favicon-512.webp";export{o as _};
